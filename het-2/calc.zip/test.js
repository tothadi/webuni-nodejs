const
    ops = require('./ops').ops,
    answer = 'mul';

console.log(ops[answer](2,3))

